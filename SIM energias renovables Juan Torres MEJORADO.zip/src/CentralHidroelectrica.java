import javax.swing.ImageIcon;

//	Project by Juan Torres
public class CentralHidroelectrica extends Central{
	//	POR HACER.
	CentralHidroelectrica(int id, String nombre, int posX, int posY, float produccionMaxima, ImageIcon imgStatusOn,
			ImageIcon imgStatusOff) {
		super(id, nombre, posX, posY, produccionMaxima, imgStatusOn, imgStatusOff);
		// TODO Auto-generated constructor stub
	}
	
	//TODO POR HACER ESTA CENTRAL (necesario terminar el clima de lluvias.)
}
